<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>Registered User</title>
    <link rel="stylesheet" href="Assets/css/registeredPage.css" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>

</head>
<body>
    <div class="main">
        <!--Menu-->
        <div class="menu">
            <img class="home" src="Assets/Imgs/icons8-home-24.png"><br>
            <a  class="one" href="">Courses</a><br>
            <a class="two" href="">Jobs</a><br>
            <a class="three" href="">Profile</a><br>
            <a class="four" href="">Log Out</a><br>
            <img class="user" src="Assets/Imgs/registered.jpg">
        </div>

        <!--The rest-->
        <div class="semi-main">

            <!--Top line-->
            <div class="topline">
                <img class="search" src="Assets/Imgs/search.png">
            <input type="search" id="search" placeholder="Search">
            <img class="mail" src="Assets/Imgs/mail.png">
            </div>

            <!--arts div-->
            <div class="arts">
                <button>Arts & Crafts</button>
                <p>20 Hours</p>
                <img src="Assets/Imgs/play.png">
            </div>

            <!--kiswahili div-->
            <div class="kiswahili">
                <button>Kiswahili</button>
                <p>50 Hours</p>
                <img src="Assets/Imgs/play.png">
            </div>

            <!--history div-->
            <div class="history">
                <button>History</button>
                <p>50 Hours</p>
                <img src="Assets/Imgs/play.png">
            </div>
            
        </div>

        <!--side-bar-->
        <div class="sidebar">
            <!--Progress div-->
         <div class="progress">
                <p class="un">Progress</p>
                <a href="">View all</a>

            <img class="sept" src="Assets/Imgs/MATH.jpg">
            <p class="deux">Mathematics</p>
            <button id="blue1"></button>
            <button id="white1"></button>
            <p class="trois">34%</p>

            <img class="six" src="Assets/Imgs/ENGLISH.jpg">
            <p class="quatre">Literature</p>
            <button id="white2"></button>
            <button id="blue2"></button>
            <p class="cinq">80%</p>
         </div>

         <!--Achievemnts div-->
         <div class="achievements">
             <p class="onze">Achievements</p>
             <a href="">View all</a>

             <img id="one" src="Assets/Imgs/rename.png">
             <p class="deuze">CERTIFICATE OF RECOGNITION</p>
             <P class="treize">SCIENCES</P>
             <img id="two" src="Assets/Imgs/invisible star.png" alt="stars">
             <img id="two" src="Assets/Imgs/invisible star.png" alt="stars">
             <img id="two" src="Assets/Imgs/invisible star.png" alt="stars">
             <img id="two" src="Assets/Imgs/invisible star.png" alt="stars">
             <img id="two" src="Assets/Imgs/invisible 2.png" alt="stars">
            </div>
        </div>
       

    </div>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\qualityeducation\sdg\resources\views/project/registeredPage.blade.php ENDPATH**/ ?>