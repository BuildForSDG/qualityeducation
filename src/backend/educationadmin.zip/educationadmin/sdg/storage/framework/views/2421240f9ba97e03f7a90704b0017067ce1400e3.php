<?php echo $__env->make('project.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
	<div class="row">
		<div class="col-sm-12 col-md-6 col-lg-6">
			<?php if(session('job')): ?>
<div class="alert alert-success">
	<?php echo e(session('job')); ?>

</div>
<?php endif; ?>
			<form action="jobss" method="post" enctype="multipart/form-data" accept-charset="utf-8">
				<?php echo e(csrf_field()); ?>

				<div class="form-group">
					<span style="color: red;"> <?php $__errorArgs = ["job_title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
					<label>Job Title</label>
					<input type="text" name="job_title" placeholder="Job Title" class="form-control">
				</div>
				<div class="form-group">
					<span style="color: red;"> <?php $__errorArgs = ["job_des"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
					<label>Job Description</label>
					<textarea name="job_des" class="form-control" placeholder="Job Description here">
						
					</textarea>
				</div>
				<div class="form-group">
					<span style="color: red;"> <?php $__errorArgs = ["date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
					<label>Application Deadline</label>
					<input type="date" name="date" class="form-control">
				</div>
				<div class="form-group">
					<span style="color: red;"> <?php $__errorArgs = ["job_attach"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
					<label>Job Attachment</label>
					<input type="file" name="job_attach" class="form-control">
				</div>
				
				<div class="text-center">
					<button class="btn btn-primary" type="submit"> Post Job</button>
				</div>
			</form>

			
		</div>
	</div>
</div><?php /**PATH C:\xampp\htdocs\qualityeducation\sdg\resources\views/project/addjob.blade.php ENDPATH**/ ?>