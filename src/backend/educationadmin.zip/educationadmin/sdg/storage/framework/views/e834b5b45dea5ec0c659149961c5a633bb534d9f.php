<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container  col-sm-12 col-md-12 col-lg-12 card summary bg-light text-black">
	<div class="row">
		<div class="col-sm-12 col-md-3 col-lg-3">
            <a  class="btn btn-link" href="addcourse">Add Courses</a><br>
            <a  class="btn btn-link" href="manage">Manage courses</a><br>
            <a class="btn btn-link" href="addjob">Add Jobs</a><br>
            <a class="btn btn-link" href="managejob">Manage Jobs</a><br>
            <img class="nav1" src="Assets/Imgs/registered.jpg">
         </div>
		<div class="col-sm-12 col-md-6 col-lg-6">
			<?php if(session('job')): ?>
<div class="alert alert-success">
	<?php echo e(session('job')); ?>

</div>
<?php endif; ?>
			<form action="jobss" method="post" enctype="multipart/form-data" accept-charset="utf-8">
				<?php echo e(csrf_field()); ?>

				<h4 class="text-center">Add job here</h4>
				<div class="form-group">
					<span style="color: red;"> <?php $__errorArgs = ["job_title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
					<label>Job Title</label>
					<input type="text" name="job_title" placeholder="Job Title" class="form-control">
				</div>
				<div class="form-group">
					<span style="color: red;"> <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
					<label>Email</label>
					<input type="email" name="email" placeholder="Email Address" class="form-control">
				</div>
				<div class="form-group">
					<span style="color: red;"> <?php $__errorArgs = ["job_des"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
					<label>Job Description</label>
					<textarea name="job_des" class="form-control" placeholder="Job Description here"></textarea>
					
				</div>
				<div class="form-group">
					<span style="color: red;"> <?php $__errorArgs = ["date"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
					<label>Application Deadline</label>
					<input type="date" name="date" class="form-control">
				</div>
				<div class="form-group">
					<span style="color: red;"> <?php $__errorArgs = ["job_attach"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
					<label>Job Attachment</label>
					<input type="file" name="job_attach" class="form-control">
				</div>
				
				<div class="text-center">
					<button class="btn btn-primary" type="submit"> Post Job</button>
				</div>
			</form>

			
		</div>
	</div>
</div>
<style type="text/css">
   	.image {
  display: inline-block;
  height: 30vh;
  width: 30vh;
  border-radius: 10px 10px 0px 0px;
  -webkit-border-radius: 10px 10px 0px 0px;
  -moz-border-radius: 10px 10px 0px 0px;
  -ms-border-radius: 10px 10px 0px 0px;
  -o-border-radius: 10px 10px 0px 0px;
}
a,button{
	color: white;
}
.container{
	padding: 15px;
}
.nav1{
margin-left: 5px;
    float: left;
    height: 50px
}
   </style><?php /**PATH C:\xampp\htdocs\qualityeducation\sdg\resources\views/admin/addjob.blade.php ENDPATH**/ ?>