<link rel="stylesheet" type="text/css" href="<?php echo e(asset('Assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('Assets/css/bootstrap.min.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('Assets/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Assets/js/bootstrap.bundle.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Assets/js/bootstrap.bundle.min.js')); ?>"></script>
<body>
	<h3 class="text-center" >welcome to fundisha Admins Portal</h3>
					<div class="container ">
					<div class="row">
						<div style="margin-top: 20vh; margin-left: auto;display: block; margin-right: auto;" class="col-sm-12 col-md-6 col-lg-6 card summary bg-light text-black text-center">
							 <?php if(session('login')): ?>
							<div class="alert alert-success">
							<?php echo e(session('login')); ?>

							</div>
							<?php endif; ?>
							<form action="loginadmin" method="post">
							<?php echo e(csrf_field()); ?>

							<p class="text-center">Admin Signin</p>
							<div class="form-group">
								<span style="color: red;"> <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
								<label>Email</label>
								<input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control">
								</div>
								<div class="form-group">
									<span style="color: red;"> <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
									<label>Password</label>
									<input type="password" name="password" class="form-control">
								</div>
								<div class="text-center"><button type="submit" class="btn btn-primary">Sign in</button></div>
								<div class="text-center"><a href="register" class="btn btn-link">create account</a></div>
									</form>
						</div>
							</div>
					</div></body>
			

			<style type="text/css">
	h3{
		color: white;
	}
	body{
    background-image: url("Assets/images/bl.jpeg");
    background-attachment: scroll;
    background-size: cover;
    background-repeat: no-repeat;
    width: 100%;
}
</style><?php /**PATH C:\xampp\htdocs\educationadmin\sdg\resources\views/admin/adminlogin.blade.php ENDPATH**/ ?>