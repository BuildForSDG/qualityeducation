<link rel="stylesheet" type="text/css" href="{{asset('Assets/css/bootstrap.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('Assets/css/bootstrap.min.css')}}">
<script type="text/javascript" src="{{asset('Assets/js/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{asset('Assets/js/bootstrap.bundle.js')}}"></script>
<script type="text/javascript" src="{{asset('Assets/js/bootstrap.bundle.min.js')}}"></script>
<body>	
	<h3 class="text-center" >welcome to fundisha Admins Portal</h3>
	<div class="container" style="margin-top: 30vh;">
		<div class="row">
			<div class="col-sm-12 col-md-4 col-lg-4">
				<button class="btn btn-secondary text-center col-sm-12 col-md-9 col-lg-9"><a style="color: white;" href="adminlogin">Login To Continue</a></button>
			</div>
			<div class="col-sm-12 col-md-4 col-lg-4">
				<button class="btn btn-secondary text-center col-sm-12 col-md-9 col-lg-9"><a style="color: white;" href="register">Signup to create an Account</a></button>
			</div>
			<div class="col-sm-12 col-md-4 col-lg-4">
				<button class="btn btn-secondary text-center col-sm-12 col-md-9 col-lg-9"><a style="color: white;" href="adminlogin">Help And About Fundisha</a></button>
			</div>
		</div>
	</div>

</body>
<style type="text/css">
	h3{
	 color: white;
	}
	body{
    background-image: url("Assets/images/bl.jpeg");
    background-attachment: scroll;
    background-size: cover;
    background-repeat: no-repeat;
    width: 100%;
}
</style>