<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.5.0.slim.min.js"
        integrity="sha256-MlusDLJIP1GRgLrOflUQtshP0TwT/RHXsl1wWGnQhs=" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link
        href="https://fonts.googleapis.com/css?family=Baloo+Bhai|Bevan|Boogaloo|Bowlby+One+SC|Caveat+Brush|Changa+One|Chewy|Concert+One|Fredoka+One|Kumar+One|Lilita+One|Monoton|Nanum+Pen+Script|Patrick+Hand|Permanent+Marker|Rock+Salt|Rubik+Mono+One|Seymour+One|Sigmar+One|Special+Elite|Titan+One|Ultra&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css?family=Alfa+Slab+One|Amaranth|Anton|Baloo|Baloo+Bhai|Bowlby+One+SC|Calistoga|Concert+One|Fredoka+One|Fugaz+One|IBM+Plex+Mono|Modak|Pangolin|Rubik+Mono+One|Special+Elite|Varela+Round|Viga&display=swap"
        rel="stylesheet">
    <link href="Assets\css\styles.css" rel="stylesheet" type="text/css">
   <!--      <link rel="stylesheet" type="text/css" href="{{asset('Assets/css/bootstrap.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('Assets/css/bootstrap.min.css')}}">
<script type="text/javascript" src="{{asset('Assets/js/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{asset('Assets/js/bootstrap.bundle.js')}}"></script>
<script type="text/javascript" src="{{asset('Assets/js/bootstrap.bundle.min.js')}}"></script> -->
    <link rel="icon" href="">
    <script src="Assets/js/script.js"></script>
    <title>FUNDISHA</title>
</head>
<style>

</style>
<body>
    <nav>
        
        <span style="font-size:30px;cursor:pointer" onclick="openNav()"><a href="home"><img src="Assets/logos/hm.png"></a></span>
    </nav>
    <h1>FUNDISHA</h1>
    <div class="signin">
        <p1><a href="#"> SIGN IN</a></p1>
        <p2><a href="#">SIGN UP</a></p2>

    </div>
    <div class="login">
        <center>
                <form  action="userlogin" method="post">
                    {{ csrf_field() }}
 @if(session('login'))
<div class="alert alert-success">
    {{session('login')}}
</div>
@endif
                    <input type="text" id="usern" name="email" placeholder="Email or username" required autocomplete="on">
                    <input type="password" id="psi" name="password" placeholder="Enter password" required><br><br>
                    <button type="submit" class="submit-btn"><a style="text-decoration: none; color: #03396c;"
                            href="#"><b>LOG IN</b></a></button><br>
                    <a href="#">
                        <div class="frg">
                        <p><b>Forgot Password?</b></p>
                    </a>
                    <p3>OR</p3>
            <div class="logi">
                <a href="#" class="fb btn">
                    <i class="fa fa-facebook fa-fw"></i>facebook
                </a>

                <a href="#" class="google btn"><i class="fa fa-google fa-fw">google
                    </i>
                </a>
            </div>  <br><br><br><br>    
                    <div class="cr" id="#cr"><a href="signup">
                            <p><b>Don't have an Account?Create One</b></p>
                        </a></div>
            </form>
        </center>
    </div>
<br><br><br><br>
    <div class="lower"> 
        <div class="contain">
            <div class="colu">
                <div class="row">
                    <div class="column">
                        <a href="#call"><img src="Assets/logos/pne.png"><b>
                                <p> +254701255700
                            </b></p></a>
    
                        <a href="#email"><img src="Assets/logos/email.png">
                            <p><b> info@fundisha.co.ke</b></p>
                        </a>
    
                        <a href="#location"><img src="Assets/logos/loca.png">
                            <p><b> 1st floor Avenue Towers Nairobi</b></p>
                        </a>
    
                    </div>
                    <div class="column">
                        <a href="">
                            <p><b>Jobs</b></p>
                        </a>
                        <a href="">
                            <p><b>Courses</b></p>
                        </a>
                        <a href="">
                            <p><b>About Us</b></p>
                        </a>
                        <a href="">
                            <p><b>Contact Us</b></p>
                        </a>
                    </div>
                    <div class="column">
                        <a href="">
                            <p><b>Blogs</b></p>
                        </a>
                        <a href="">
                            <p><b>FAQs</b></p>
                        </a>
                        <a href="">
                            <p><b>Privacy Policy</b></p>
                        </a>
                        <a href="">
                            <p><b>Terms & Conditions</b></p>
                        </a>
                    </div>
                </div>
            </div>
            <hr style="color: solid #e2af6d; border-top: 3px solid #e2af6d;">
        </div>
        <div class="footer">
        <a href=" #">
            <h4>FUNDISHA</h4></a>
            <p>&copy 2020. All rights reserved</p>
        </div>
    </div>
</body>

</html>
<!-- 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.5.0.slim.min.js"
    integrity="sha256-MlusDLJIP1GRgLrOflUQtshP0TwT/RHXsl1wWGnQhs=" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link
    href="https://fonts.googleapis.com/css?family=Baloo+Bhai|Bevan|Boogaloo|Bowlby+One+SC|Caveat+Brush|Changa+One|Chewy|Concert+One|Fredoka+One|Kumar+One|Lilita+One|Monoton|Nanum+Pen+Script|Patrick+Hand|Permanent+Marker|Rock+Salt|Rubik+Mono+One|Seymour+One|Sigmar+One|Special+Elite|Titan+One|Ultra&display=swap"
    rel="stylesheet">
<link
    href="https://fonts.googleapis.com/css?family=Alfa+Slab+One|Amaranth|Anton|Baloo|Baloo+Bhai|Bowlby+One+SC|Calistoga|Concert+One|Fredoka+One|Fugaz+One|IBM+Plex+Mono|Modak|Pangolin|Rubik+Mono+One|Special+Elite|Varela+Round|Viga&display=swap"
    rel="stylesheet">
<link href="Assets/Imgs/jobs.css" rel="stylesheet" type="text/css">
<link rel="icon" href="">
<script src="Assets/js/script.js"></script>
<title>FUNDISHA</title>
</head>
<style>
    body,
    html{
        background-color: #03396c;   
    }
    .secteach{
    position: relative;
background-image: url("Assets/Imgs/lockers.jpg");
background-size: cover;
width: 55%;
background-repeat: no-repeat;
background-position: center;
border-radius: 20px;
display: inline-block;
height: 180px;
}
    .elem{
    position: relative;
background-image: url("Assets/Imgs/blackboard.jpg");
background-size: cover;
width: 40%;
background-repeat: no-repeat;
background-position: center;
border-radius: 20px;
margin-top: -200px;
float: right;
height: 180px;
}
.french{
    display: inline-block;
    background-image: url("Assets/Imgs/eiffel.jpg");
    background-size: cover;
width: 40%;
background-repeat: no-repeat;
background-position: center;
border-radius: 20px;
height: 180px;
}
.lec{
    position: relative;
background-image: url("Assets/Imgs/grad.jpg");
background-size: cover;
width: 55%;
background-repeat: no-repeat;
background-position: center;
border-radius: 20px;
margin-left: 288px;
margin-top: -178px;
height: 180px;
}
.lec p{
    position: relative;
text-align: justify;
color: white;
font-family:'Quicksand';
left: 150px;
top: 100px;
}
</style>
<body>
    <div class="sidenav">
        <a href="home"><img src="Assets/logos/hm.png"></a>
        <a href="#"><p> Courses</p></a>
        <a href="#"><p> Jobs</p></a>
        <a href="#"><p> Profile</p></a>
        <a href="#"><p> Log out</p></a>
        <a href="#"><img src="Assets/Imgs/registered.jpg" style="border-radius: 5px; height: 100px; width: 90px;"></a>
      </div>
      
      <div class="main">
       <div class="nav">
        <input type="text" placeholder="Search..">
        <img src="Assets/logos/email.png">
       </div> <br>
        <div class="hiring">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
           <p>WE ARE HIRING !</p>
        </div><br>
        <div class="teachers">
            <div class="secteach"><br><br>
                <div class="white" style="background-color: white; opacity: 0.7;">
                    <p style="color: #E2AF6D;"><b>Secondary School Teachers</b></p>
                    
                <p style="color: #03396c;">Maths/Physics, Chemistry/Biology, 
                    Geography/CRE, Maths/Business Studies
                </p>
                </div>
               <br><br>
            </div><br><br>
            <div class="elem">
                <br><br>
                <p>We are on the look out for</p>
                <p>ELEMENTARY MATH Teachers</p> 
                <p>St.Marys Schools</p> 
                <p>Send your CV at info@stmarys.com</p>
                <br>
            </div>
            <div class="french"><br><br>
                <div class="white" style="background-color: white; opacity: 0.7;">
                    <p>FRENCH TEACHER </p>
                       <p>NORTH-HORR PRIMARY SCHOOL</p> 
                        <p>nhps@gmail.com</p>
                </div>
                <br>
            </div>
            <div class="lec"><br>
                <b><p>ACCOUNTING LECTURER</p>
                <p>KENYATTA UNIVERSITY</p></b>
                <br>
            </div>
        </div>
        <br>
        <div class="main2">
            <div class="progr">
                <div class="mag">
                    <p1>Progress</p1>
                    <p2>View All</p2>
                    <img src="Assets/Imgs/MATH.jpg">
                <p3>Mathematics</p3>
                <button class="btn1"></button>
                <p4>34%</p4>
                <br><br>
                <img src="Assets/Imgs/ENGLISH.jpg">
                <p3>Literature</p3>
                <button class="btn1"></button>
                <p4>80%</p4>
            </div>
        </div>
        <br>
        <div class="achie">
            <div class="magr">
            <p1>Achievements</p1>
            <p2>View All</p2>
            <img src="Assets/Imgs/rename.png">
            <p3>CERTIFICATE OF RECOGNITION</p3>
            <p4>SCIENCES</p4>
            <img id="str" src="Assets/Imgs/invisible star.png">
            <img id="str"src="Assets/Imgs/invisible star.png">
            <img id="str" src="Assets/Imgs/invisible star.png">
            <img id="str" src="Assets/Imgs/invisible star.png">
            <img id="str" src="Assets/Imgs/invisible star.png">
        </div>
      </div>
    </div>
</body>
</html>
 -->
