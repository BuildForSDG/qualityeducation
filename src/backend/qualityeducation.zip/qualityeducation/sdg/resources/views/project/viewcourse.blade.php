
      <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
    <link href="Assets/css/literature.css" rel="stylesheet" type="text/css">
<body style="background-color: #03396C;">
  <a href="home"><img src="Assets/logos/hm.png" alt=""></a>
  @foreach($course as $key => $value)
    <h2 style="text-align: center;">{{$value->course_title}}</h2>
     <div class="menu">
        <button class="btn 1" onclick="return myFunction2();">Overview</button>
        <button class="btn" onclick="return myFunction()">Modules</button>
        <button class="btn" onclick="return myFunction3();">Schedules</button>
        <button class="btn" onclick="return myFunction4();">Certification/Exams</button>
     </div>
    <div class="content">
        <div id="overviewContent">
            @if(@count($ada)>0)
      @for($i=0;$i<@count($ada);$i++)
 <h4 >{{$ada[$i]->c_no}} {{$ada[$i]->title}}</h4>
      <video style="height: auto; width: 90%; margin-top: 100vh;" class="text-center" controls=""   poster='images/{{$ada[$i]->video}}' src='images/{{$ada[$i]->video}}'></video>
       <h6>{{$ada[$i]->des}}</h6>
  @endfor
      @else
      <video style="height: auto; width: 80%;"  controls=""   poster='images/{{$value->course_image}}' src='images/{{$value->course_video}}'></video>
      <h6 >{{$value->course_content}}</h6>
      @endif
        </div>
        <div id="modulesContent">
          <h5>Chapters</h5>
             @for($i=0;$i<@count($chapter);$i++)
 <a style="color: white;" href='getchapters?id={{$chapter[$i]->id}}&c_no={{$chapter[$i]->c_no}}&course_id={{$chapter[$i]->course_id}}'>Chapter {{$chapter[$i]->c_no}} {{$chapter[$i]->title}}</a><br>
  @endfor
        </div>
        <div id="scheduleContent">
            <table>
                <tr>
                    <th>Start Date</th>
                    <th>Time</th>
                    <th>Duration</th>
                    <th>Location</th>
                </tr>
                <tr>
                    <td>Jan 5 2020</td>
                    <td>9.00am - 5.00pm</td>
                    <td>10 days</td>
                    <td>Live Online</td>
                </tr>
                <tr>
                    <td>Feb 5 2020</td>
                    <td>9.00am - 5.00pm</td>
                    <td>10 days</td>
                    <td>Live Online</td>
                </tr>
                <tr>
                    <td>Mar 5 2020</td>
                    <td>9.00am - 5.00pm</td>
                    <td>10 days</td>
                    <td>Live Online</td>
                </tr>
                <tr>
                    <td>Apr 5 2020</td>
                    <td>9.00am - 5.00pm</td>
                    <td>10 days</td>
                    <td>Live Online</td>
                </tr>
            </table>
        </div>
        <div id="examContent">
            <p>
                About the Exam<br><br>
                - Number of questions: 125<br>
                - Test duration: 4 hours<br>
                -Test format: Multiple choice<br>
                -Exam prefix: LIT 001<br>
            </p>
        </div>
    </div>
    @endforeach
    <div class="enquire" style="border: 2px ">
        <div class="heading">Enquiry</div>
        <input class="z" type="text" id="math" placeholder="Mathematics">
        <input class="z" type="text" id="name" placeholder="Your Name*">
        <input class="z" type="email" id="email" placeholder="Email*">
        <input class="z" type="text" id="telephone" placeholder="Phone Number">
        <textarea id="message" class="z" placeholder="messsage here"></textarea>
        <button>ENQUIRE</button>
    </div>
</body>
   @include('project.footer')
   <script>
  var x = document.getElementById("overviewContent");
  var x1 = document.getElementById("modulesContent");
  var x2 = document.getElementById("scheduleContent");
  var x3 = document.getElementById("examContent");
  x.style.display="block";
   x1.style.display="none";
    x2.style.display="none";
     x3.style.display="none";

    function myFunction2() {
x.style.display="block";
   x1.style.display="none";
    x2.style.display="none";
     x3.style.display="none";
}

    function myFunction() {
  x.style.display="none";
   x1.style.display="block";
    x2.style.display="none";
     x3.style.display="none";
}

function myFunction3() {
  x.style.display="none";
   x1.style.display="none";
    x2.style.display="block";
     x3.style.display="none";
}

function myFunction4() {
  x.style.display="none";
   x1.style.display="none";
    x2.style.display="none";
     x3.style.display="block";
}
   </script>
   <style type="text/css">
     h4,h6,h2,h5{
      color: white;
     }
   </style>