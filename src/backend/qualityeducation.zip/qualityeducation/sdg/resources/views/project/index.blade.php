<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="Assets/js/jquery-3.5.0.js" integrity="sha256-MlusDLJIP1GRgLrOflUQtshP0TwT/RHXsl1wWGnQhs=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="{{asset('Assets/js/jquery.min.js')}}"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="Assets/css/bootstrap.min.css">
    <link
        href="https://fonts.googleapis.com/css?family=Baloo+Bhai|Bevan|Boogaloo|Bowlby+One+SC|Caveat+Brush|Changa+One|Chewy|Concert+One|Fredoka+One|Kumar+One|Lilita+One|Monoton|Nanum+Pen+Script|Patrick+Hand|Permanent+Marker|Rock+Salt|Rubik+Mono+One|Seymour+One|Sigmar+One|Special+Elite|Titan+One|Ultra&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css?family=Alfa+Slab+One|Amaranth|Anton|Baloo|Baloo+Bhai|Bowlby+One+SC|Calistoga|Concert+One|Fredoka+One|Fugaz+One|IBM+Plex+Mono|Modak|Pangolin|Rubik+Mono+One|Special+Elite|Varela+Round|Viga&display=swap"
        rel="stylesheet">
    <link href="Assets/css/styles.css" rel="stylesheet" type="text/css">
    <link rel="icon" href="">
    <script src="Assets/js/script.js"></script>
    <title>FUNDISHA</title>
</head>
<style>
    .stu{
    background-image: url("Assets/images/bl.jpeg");
    background-attachment: scroll;
    background-size: cover;
    background-repeat: no-repeat;
    width: 100%;
}
#snackbar,
#snackba,
#snackb{
    visibility: hidden;
    min-width: 350px;
    margin-left: -125px;
    background-color: #03396c;
    opacity: 90%;
    color: #fff;
    font-weight: bold;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1;
    left: 50%;
    bottom: 30px;
    font-size: 17px;
    border-radius: 10px;
}

#snackbar.show {
    visibility: visible;
    -webkit-animation: fadein 1.5s, fadeout 0.5s 5.5s;
    animation: fadein 1.5s, fadeout 0.5s 5.5s;
}
#snackba.show {
    visibility: visible;
    -webkit-animation: fadein 1.5s, fadeout 0.5s 5.5s;
    animation: fadein 1.5s, fadeout 0.5s 5.5s;
}
#snackb.show {
    visibility: visible;
    -webkit-animation: fadein 1.5s, fadeout 2.5s 5.5s;
    animation: fadein 1.5s, fadeout 0.5s 5.5s;
}

@-webkit-keyframes fadein {
    from {bottom: 0; opacity: 0;} 
    to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
    from {bottom: 0; opacity: 0;}
    to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
    from {bottom: 30px; opacity: 1;} 
    to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
    from {bottom: 30px; opacity: 1;}
    to {bottom: 0; opacity: 0;}
}
/*media screen*/
@media screen and (max-width: 500px) {
#snackbar,
#snackba,
#snackb{
    visibility: hidden;
    min-width: 200px;
    margin-left: -120px;
    background-color: #03396c;
    opacity: 90%;
    color: #fff;
    font-weight: bold;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: scroll;
    z-index: 1;
    bottom: 30px;
    font-size: 15px;
    border-radius: 5px;
}
}
@media screen and (max-width: 320px) {
#snackbar,
#snackba,
#snackb{
    visibility: hidden;
    min-width: 100px;
    margin-left: -120px;
    background-color: #e2af6d;
    opacity: 90%;
    color: #fff;
    font-weight: bold;
    text-align: center;
    border-radius: 2px;
    padding: 10px;
    position: fixed;
    z-index: 1;
    bottom: 30px;
    font-size: 12px;
    border-radius: 5px;
}
}
</style>
<body scroll-behavior: smooth;>
<div class="header" id="hea" scroll-behavior: smooth;>
    <a href="index.html"><h2>FUNDISHA</h2></a>
    <a href="index.html"><img src="Assets/icons/earth.png">
        </a>
    <a href="index.html"><img src="Assets/icons/act.png"></a>
    <a href="index.html"><img src="Assets/icons/search.png"></a>
</div>
<div class="stu" alt="responsive">
<div class="navbar">
    <a id="signup" href="signup"><p>SIGN UP</p></a>
    <a id="login" href="login"><p>LOG IN</p></a>
    <a id="logout" href="logout1"  onClick="return confirm('Confirm Logout');"><p>logout</p></a>
    <a href="#"><p>BLOG</p></a>
    <a href="#cos"><p>COURSES</p></a>
    <a href="#jbs"><p>JOBS</p></a>
    <a href="aboutus"><p>ABOUT US</p></a>
    <!-- <a href="home.html"><img src="logos/hm.png"></a> -->
</div>
<br><br><br><br>
<br><br>
<div class="sidenav" >
    <a href="#call" onclick="myFunction1()"><img src="Assets/logos/pne.png"></a>
    <div id="snackbar">Call us: +254701-255-700</div>
    <a href="#share" ><img src="Assets/logos/share.png"></a>
    <a href="#email" onclick="myFunction2()"><img src="Assets/logos/email.png"></a>
    <div id="snackba">Email us: info@fundisha.co.ke</div>
    <a href="#location" onclick="myFunction3()"><img src="Assets/logos/loca.png"></a>
    <div id="snackb">Find us: 1st flr Avenue Towers Nairobi</div>
    <script>
        function myFunction1() {
            var x = document.getElementById("snackbar");
            x.className = "show";
            setTimeout(function () { x.className = x.className.replace("show", ""); }, 6000);
        }
        function myFunction2() {
            var x = document.getElementById("snackba");
            x.className = "show";
            setTimeout(function () { x.className = x.className.replace("show", ""); }, 6000);
        }
        function myFunction3() {
            var x = document.getElementById("snackb");
            x.className = "show";
            setTimeout(function () { x.className = x.className.replace("show", ""); }, 6000);
        }
    </script>
</div>
<br><br><br><br>
<br><br>
</div>
<div class="contain">
<div class="courses" id="cos">
    <h3>COURSES</h3>
    @for($i=0;$i<@count($courses);$i++)
    <div class="container">
    <img src='images/{{$courses[$i]->course_image}}' alt="Avatar" class="image">
    <div class="overlay"><a href="morecourses">{{$courses[$i]->course_title}}</a></div>
    </div>
     @if($i==2)
    @break
    @endif
    @endfor
   <div> <a href="morecourses">view more courses</a></div>
</div>
<hr>
<div class="jobs" id="jbs">
    <h3>JOBS</h3>
    @for($i=0;$i<@count($jobs);$i++)
    <div class="container">
        <img src="images/{{$jobs[$i]->job_attachment}}" alt="Avatar" class="image">
         <div class="overlay"><a href="jobs">{{$jobs[$i]->job_title}}</a></div>
    </div>
    @if($i==2)
    @break
    @endif
    @endfor
</div>
</div>
<div class="partn"><br>
    <div class="contain">
    <center>
        <h3>OUR PARTNERS</h3>
    </center>
    <div class="gallery">
        <img src="Assets/icons/facebook.png" alt="facebook">
        <a href="#"><div class="descr">FACEBOOK</div></a>
    </div>
    <div class="gallery">
        <img src="Assets/icons/andela.png" alt="andela">
        <a href="#"><div class="descr">ANDELA</div></a>
    </div>
    <div class="gallery">
        <img src="Assets/icons/un.png" alt="united">
        <a href="#"><div class="descr">UNITED NATIONS</div></a>
    </div>
    <hr style="color: solid #e2af6d; border-top: 3px solid #e2af6d;">
</div>
</div>
<div class="lower">
    <div class="contain">
        <div class="colu">
        <div class="row">
            <div class="column">
            <a href="#call"><img src="Assets/logos/pne.png"><b><p>+254701255700</b></p></a>
            
            <a href="#email"><img src="Assets/logos/email.png"><p><b>info@fundisha.co.ke</b></p></a>
            
            <a href="#location"><img src="Assets/logos/loca.png"><p><b>1st floor Avenue Towers Nairobi</b></p></a>
            
            </div>
            <div class="column">  
                <a href=""><p><b>Jobs</b></p></a>
                <a href=""><p><b>Courses</b></p></a>
                <a href=""><p><b>About Us</b></p></a>
                <a href=""><p><b>Contact Us</b></p></a>
            </div>
            <div class="column">
                <a href=""><p><b>Blogs</b></p></a>
                <a href=""><p><b>FAQs</b></p></a>
                <a href=""><p><b>Privacy Policy</b></p></a>
                <a href=""><p><b>Terms & Conditions</b></p></a>
            </div>
        </div>
        </div>
   <hr style="color: solid #e2af6d; border-top: 3px solid #e2af6d;"> 
</div>
<div class="footer">
    <a href="#"><h4>FUNDISHA</h4></a>
    <p>&copy 2020. All rights reserved</p>
</div>
</div>
@if(session('email'))
<style type="text/css">
    #login,#signup{
        display: none;
    }
    #logout{
        display: block;
    }
</style>
@else
<style type="text/css">
    #login,#signup{
        display: block;
    }
    #logout{
        display: none;
    }
</style>
@endelse
@endif
</body>
</html>
