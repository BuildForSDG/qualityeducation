<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>Registered User</title>
    <link rel="stylesheet" href="Assets/css/registeredPage.css" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Quicksand' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>

</head>
<body>
    <div class="main">
        <!--Menu-->
        <div class="menu">
           
        </div>
        <!-- <div class="container card summary bg-light text-black col-sm-12 col-md-12 col-lg-12" >
       <div class="row">
         <div class="col-lg-12 col-md-2 col-lg-2"></div>
         <div class="col-sm-12 col-md-10 col-lg-10">
           <div class=""></div>
         </div>
       </div>

    </div> -->

        <!--The rest-->
        <div class="semi-main">

            <!--Top line-->
            <div class="topline">
                <img class="search" src="Assets/Imgs/search.png">
            <input type="search" id="search" placeholder="Search">
            <img class="mail" src="Assets/Imgs/mail.png">
            </div>

            <!--arts div-->
            <div class="arts">
                <button>Arts & Crafts</button>
                <p>20 Hours</p>
                <img src="Assets/Imgs/play.png">
            </div>

            <!--kiswahili div-->
            <div class="kiswahili">
                <button>Kiswahili</button>
                <p>50 Hours</p>
                <img src="Assets/Imgs/play.png">
            </div>

            <!--history div-->
            <div class="history">
                <button>History</button>
                <p>50 Hours</p>
                <img src="Assets/Imgs/play.png">
            </div>
            
        </div>

        <!--side-bar-->
        <div class="sidebar">
            <!--Progress div-->
         <div class="progress">
                <p class="un">Progress</p>
                <a href="">View all</a>

            <img class="sept" src="Assets/Imgs/MATH.jpg">
            <p class="deux">Mathematics</p>
            <button id="blue1"></button>
            <button id="white1"></button>
            <p class="trois">34%</p>

            <img class="six" src="Assets/Imgs/ENGLISH.jpg">
            <p class="quatre">Literature</p>
            <button id="white2"></button>
            <button id="blue2"></button>
            <p class="cinq">80%</p>
         </div>

         <!--Achievemnts div-->
         <div class="achievements">
             <p class="onze">Achievements</p>
             <a href="">View all</a>

             <img id="one" src="Assets/Imgs/rename.png">
             <p class="deuze">CERTIFICATE OF RECOGNITION</p>
             <P class="treize">SCIENCES</P>
             <img id="two" src="Assets/Imgs/invisible star.png" alt="stars">
             <img id="two" src="Assets/Imgs/invisible star.png" alt="stars">
             <img id="two" src="Assets/Imgs/invisible star.png" alt="stars">
             <img id="two" src="Assets/Imgs/invisible star.png" alt="stars">
             <img id="two" src="Assets/Imgs/invisible 2.png" alt="stars">
            </div>
        </div>
       

    </div>
    
</body>
</html>