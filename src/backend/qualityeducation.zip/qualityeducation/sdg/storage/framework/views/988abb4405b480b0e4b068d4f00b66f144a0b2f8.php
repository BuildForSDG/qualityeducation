<script src="Assets/js/jquery-3.5.0.js" integrity="sha256-MlusDLJIP1GRgLrOflUQtshP0TwT/RHXsl1wWGnQhs=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="<?php echo e(asset('Assets/js/jquery.min.js')); ?>"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="Assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('Assets/css/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('Assets/css/bootstrap.min.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('Assets/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Assets/js/bootstrap.bundle.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Assets/js/bootstrap.bundle.min.js')); ?>"></script>



 <div class="container col-sm-12 col-md-12 col-lg-12" style="color: white; margin-top: 3vh; background-color: #03396C;" >
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <center>
        <h3 >OUR PARTNERS</h3>
    </center>
    <div class="container all1">
      <div class="row">
        <div class="col-sm-12 col-md-4 col-lg-4">
        <div class="text-center"><img src="Assets/icons/facebook.png" class="col-sm-6 col-md-6 col-lg-6 text-center"  alt="facebook"></div>
        <a href="#"><div class="text-center">FACEBOOK</div></a>
    </div>
    <div class="col-sm-12 col-md-4 col-lg-4">
        <div class="text-center"><img src="Assets/icons/andela.png" class="col-sm-6 col-md-6 col-lg-6 text-center" alt="andela"></div>
        <a href="#"><div class="text-center">ANDELA</div></a>
    </div>
    <div class="col-sm-12 col-md-4 col-lg-4">
        <div class="text-center"><img src="Assets/icons/un.png" class="col-sm-6 col-md-6 col-lg-6 text-center" alt="united"></div>
        <a href="#"><div class="text-center">UNITED NATIONS</div></a>
    </div>
      </div>
    </div>
    
    <hr style="color: solid #e2af6d; border-top: 3px solid #e2af6d;">
        </div>
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="container all2" >
              <div class="row">
                <div class="col-sm-12 col-md-4 col-lg-4">
                  <h3 class="text-center">Contact Us</h3>
                  <hr style="color: solid #e2af6d; border-top: 3px solid #e2af6d;">
                 <a href="#call"><img src="Assets/logos/pne.png"><p><b>+254701255700</b></p></a>
            
            <a href="#email"><img src="Assets/logos/email.png"><p><b>info@fundisha.co.ke</b></p></a>
            
            <a href="#location"><img src="Assets/logos/loca.png"><p><b>1st floor Avenue Towers Nairobi</b></p></a>
         
        </div>
        <div class="col-sm-12 col-md-4 col-lg-4" >
          <h3 class="text-center">Quick Links</h3>
          <hr style="color: solid #e2af6d; border-top: 3px solid #e2af6d;">
              <a href="jobs"><p><b>Jobs</b></p></a>
                <a href="morecourses"><p><b>Courses</b></p></a>
                <a href=""><p><b>About Us</b></p></a>
                <a href=""><p><b>Contact Us</b></p></a>
            
        </div>
        <div class="col-sm-12 col-md-4 col-lg-4">
          <h3 class="text-center">Others</h3>
          <hr style="color: solid #e2af6d; border-top: 3px solid #e2af6d;">
            <a href=""><p><b>Blogs</b></p></a>
                <a href=""><p><b>FAQs</b></p></a>
                <a href=""><p><b>Privacy Policy</b></p></a>
                <a href=""><p><b>Terms & Conditions</b></p></a>
            
        </div>
              </div>
            </div>
<hr style="color: solid #e2af6d; border-top: 3px solid #e2af6d;"> 
    </div>
        <div class="col-sm-12 col-md-12 col-lg-12" >
             <a href="#"><h4>FUNDISHA</h4></a>
    <p style="float: right;">&copy 2020. All rights reserved</p>
        </div>
    </div>
</div>
<style type="text/css">
    .all1 img{
  width: 200px;
  height: 150px;
}
.all2 img{
  width: 20px;
  height: 20px;
}
</style><?php /**PATH C:\xampp\htdocs\qualityeducation\sdg\resources\views/project/footer.blade.php ENDPATH**/ ?>