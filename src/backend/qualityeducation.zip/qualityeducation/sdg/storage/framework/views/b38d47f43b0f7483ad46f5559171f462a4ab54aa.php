 <?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div style="background-color: #efefef;">
<div style="width: 100%; background: blue; color: white; height: 50px; margin-bottom: 10px;">
	<header>
	<nav> 
    <h3 class="text-center" >Manage Courses here</h3>
    </nav></header>
</div>
 <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container card summary bg-light text-black col-sm-12 col-md-12 col-lg-12" style="padding: 10px;">
	<div class="row">
	<div class="col-sm-12 col-md-4 col-lg-4">
		<a style="color: blue;" href="#"><?php echo e($value->course_title); ?></a><br>
		<?php for($i=0;$i<@count($chapter);$i++): ?>
 <a style="color: blue;" href='getchapter?id=<?php echo e($chapter[$i]->id); ?>&c_no=<?php echo e($chapter[$i]->c_no); ?>&course_id=<?php echo e($chapter[$i]->course_id); ?>'>Chapter <?php echo e($chapter[$i]->c_no); ?> <?php echo e($chapter[$i]->title); ?></a><br>	 
  <?php endfor; ?>
  <button class="btn btn-secondary"  data-toggle="modal" data-target="#chap">Add chapter</button>
    </div>
    <div class="col-sm-12 col-md-8 col-lg-8">
    	<?php if(@count($ada)>0): ?>
    	<?php for($i=0;$i<@count($ada);$i++): ?>
 <p><?php echo e($ada[$i]->c_no); ?> <?php echo e($ada[$i]->title); ?></p>
 <p><?php echo e($ada[$i]->des); ?></p>
    	<video style="height: 40vh; width: 80%;" controls=""   poster='images/<?php echo e($ada[$i]->video); ?>' src='images/<?php echo e($ada[$i]->video); ?>'></video>
    	<div style="padding: 10px;"><button  class="btn btn-danger"  data-toggle="modal" data-target="#kk">Delete this chapter</button></div>
    	 <div class="modal fade" id="kk">
        <div class="modal-dialog">
          <div class="modal-content">
          <div class="modal-body">
            <form action="deletechapter" method="post">
                            <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <label>Are you sure you want to delete this chapter?</label>
                <input type="text" name="id" hidden="true" value="<?php echo e($ada[$i]->c_no); ?>">
              </div>
                <div class="text-center"><button data-dismiss="modal" class="btn btn-secondary">cancel</button>
                <button type="submit" class="btn btn-primary">Yes</button></div>
                  </form>
              </div>
              
          
          </div>
        </div>
        </div>
  <?php endfor; ?>
    	<?php else: ?>
    	<p><?php echo e($value->course_content); ?></p>
    	<video style="height: 40vh; width: 80%;" controls=""   poster='images/<?php echo e($value->course_image); ?>' src='images/<?php echo e($value->course_video); ?>'></video>
    	<?php endif; ?>
    	<div class="modal fade" id="chap">
    		<div class="modal-dialog" >
    			<div class="modal-content">
    				<div class="modal-head">
    					<button data-dismiss="modal" class="close">
              <span>&times</span>
            </button>
    				</div>
    				<div class="modal-body">
    					<?php if(session('status')): ?>
<div class="alert alert-success">
	<?php echo e(session('status')); ?>

</div>
<?php endif; ?>
		<form action="add_chapter" role='form' style="padding: 10px;"  method="post" enctype="multipart/form-data" accept-charset="utf-8">
							<?php echo e(csrf_field()); ?>

							<p class="text-center">Add course Chapter</p>
							<input type="text" name="course_id" hidden="true" value="<?php echo e($value->course_id); ?>"  class="form-control">
							<div class="form-group">
								<span style="color: red;"> <?php $__errorArgs = ["c_no"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
								<label>Chapter Number</label>
								<input type="text" name="c_no"  class="form-control">
								</div>
								<div class="form-group">
									<span style="color: red;"> <?php $__errorArgs = ["title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
									<label>Chapter Title</label>
									<input type="text" name="title" class="form-control">
								</div>
								<div class="form-group">
									<span style="color: red;"> <?php $__errorArgs = ["des"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
									<label>Chapter Description</label>
									<textarea name="des" class="form-control" placeholder="description here...."></textarea>
								</div>
								<div class="form-group">
									<span style="color: red;"> <?php $__errorArgs = ["file"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
									<label>Chapter Video</label>
									<input type="file" name="video" class="form-control">
								</div>
								<button type="submit" class="btn btn-primary">Add chapter</button>
									</form>
    				</div>
    			</div>
    		</div>
    	</div>
    	
    </div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<style type="text/css">
   	.image {
  display: inline-block;
  height: 30vh;
  width: 30vh;
  border-radius: 10px 10px 0px 0px;
  -webkit-border-radius: 10px 10px 0px 0px;
  -moz-border-radius: 10px 10px 0px 0px;
  -ms-border-radius: 10px 10px 0px 0px;
  -o-border-radius: 10px 10px 0px 0px;
}
a,button{
	color: white;
}
.container{
	padding: 15px;
}
.nav1{
margin-left: 5px;
    float: left;
    height: 50px
}
   </style><?php /**PATH C:\xampp\htdocs\qualityeducation\sdg\resources\views/admin/viewmore.blade.php ENDPATH**/ ?>