
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container col-sm-12 col-md-12 col-lg-12 card summary bg-light text-black">
	<div class="row" >
		<div class="col-sm-12 col-md-3 col-lg-3">
            <a  class="btn btn-link" href="addcourse">Add Courses</a><br>
            <a  class="btn btn-link" href="manage">Manage courses</a><br>
            <a class="btn btn-link" href="addjob">Add Jobs</a><br>
            <a class="btn btn-link" href="managejob">Manage Jobs</a><br>
            <img class="nav1" src="Assets/Imgs/registered.jpg">
         </div>
		<div class="col-sm-12 col-md-6 col-lg-6" >
			<?php if(session('status')): ?>
<div class="alert alert-success">
	<?php echo e(session('status')); ?>

</div>
<?php endif; ?>
		<form role="form" action="course" method="post" enctype="multipart/form-data" accept-charset="utf-8">
			<?php echo e(csrf_field()); ?>

			<p class="text-center">Add Course</p>
			<div class="form-group">
				<span style="color: red;"> <?php $__errorArgs = ["course_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
				<label>Course Id:</label>
				<input type="text" name="course_id" class="form-control">
			</div>
			<div class="form-group">
				<span style="color: red;"> <?php $__errorArgs = ["course_title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
				<label>Course Title:</label>
				<input type="text" name="course_title" class="form-control">
			</div>
			<div class="form-group">
				<label>Course Image:</label>
				<span style="color: red;"> <?php $__errorArgs = ["course_image"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
				<input type="file" name="course_image" class="form-control">
			</div>
			<div class="form-group">
				<span style="color: red;"> <?php $__errorArgs = ["course_video"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
				<label>Course Video</label>
				<input type="file" name="course_video" class="form-control">
			</div>
			<div class="form-group">
				<span style="color: red;"> <?php $__errorArgs = ["course_content"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<?php echo e($message); ?>

							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
				<label>Course Content:</label>
				<textarea type="text" name="course_content" class="form-control"></textarea>
				<div class="">
					<button style="margin-top: 1vh;" type="submit" class="btn btn-primary">Add Course</button>
				</div>
			</div>
		</form>
	</div></div>
	
</div>
<style type="text/css">
   	.image {
  display: inline-block;
  height: 30vh;
  width: 30vh;
  border-radius: 10px 10px 0px 0px;
  -webkit-border-radius: 10px 10px 0px 0px;
  -moz-border-radius: 10px 10px 0px 0px;
  -ms-border-radius: 10px 10px 0px 0px;
  -o-border-radius: 10px 10px 0px 0px;
}

.container{
	padding: 15px;
}
.nav1{
margin-left: 5px;
    float: left;
    height: 50px
}
a,button{
	color: white;
}
   </style>}
<?php /**PATH C:\xampp\htdocs\qualityeducation\sdg\resources\views/admin/addcourse.blade.php ENDPATH**/ ?>