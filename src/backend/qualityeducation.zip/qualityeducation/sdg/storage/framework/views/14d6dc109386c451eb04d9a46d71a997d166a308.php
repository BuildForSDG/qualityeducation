    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('Assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('Assets/css/bootstrap.min.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('Assets/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Assets/js/bootstrap.bundle.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Assets/js/bootstrap.bundle.min.js')); ?>"></script>

<div class="btn-group navbar-header">
		<a class="btn brn-default" href="admin" style="margin-left: 10px;margin-right: 10px;margin-top: 1vh;">Home</a>
		<div class="dropdown" >
		<button class="btn btn-primary dropdown-toggle" style="margin-left: 10px;margin-right: 10px;margin-top: 1vh;" type="button" id="dropdownmenu1" data-toggle="dropdown">Courses<span class="caret"></span>
		</button>
		<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownmenu1">
			<li><a href="addcourse" role="menuitem">Add course</a> </li>
			<li><a href="manage" role="menuitem">Manage Courses</a> </li>
			<li><a href="#" role="menuitem">Courses Certification</a> </li>
			<li><a href="#" role="menuitem">View Enrolled</a> </li>
			<li><a  href="#" role="menuitem">View Certified</a> </li>	
		</ul>
		</div>
		<div class="dropdown" >
		<button class="btn btn-primary dropdown-toggle" style="margin-left: 10px;margin-right: 10px;margin-top: 1vh;" type="button" id="dropdownmenu1" data-toggle="dropdown">Jobs<span class="caret"></span>
		</button>
		<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownmenu1">
			<li><a href="addjob" role="menuitem">Add Job</a> </li>
			<li><a href="manage" role="menuitem">Manage Jobs</a> </li>
		</ul>
		</div>
		<button style="margin-left: 10px;margin-right: 10px;margin-top: 1vh;" class="btn btn-link"><a href="adminlogin">login</a></button>
		<button style="margin-left: 10px;margin-right: 10px;margin-top: 1vh;" class="btn btn-link"><a href="register">register</a></button>
		<button style="margin-left: 10px;margin-right: 10px;margin-top: 1vh;" class="btn btn-danger" id="logout" data-toggle="modal" data-target="#logo">logout</button>
	</div>
	<hr>
	<?php echo e(csrf_field()); ?>

	<span><?php if(session()->has('email')){
	echo ('welcome again '.session('email'));
} ?></span>
				<div class="modal fade" id="logo">
				<div class="modal-dialog">
					<div class="modal-content">
						<p class="text-center"><?php
							if(session()->has('email')){
	                         echo (session('email'));
                             }?></p>
			
					<div class="modal-body">
						<form action="logout" method="post">
                            <?php echo e(csrf_field()); ?>

							<div class="form-group">
								<label>Are you sure you want to logout?</label>
							</div>
								<button data-dismiss="modal" class="btn btn-secondary">cancel</button>
								<button type="submit" class="btn btn-primary">Yes</button>
									</form>
							</div>
							
					
					</div>
				</div>
				</div>
<style type="text/css">

</style>
<?php /**PATH C:\xampp\htdocs\qualityeducation\sdg\resources\views/project/admin.blade.php ENDPATH**/ ?>