

<!DOCTYPE html>
<html>
<head>
	<title>Kq mall</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<script type="text/javascript" src="assets/js/jquery.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.bundle.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="btn-group navbar-header">
		<a class="btn brn-default" href="home">Home</a>
		<div class="dropdown" >
			<button class="btn btn-primary dropdown-toggle" type="button" id="dropdownmenu1" data-toggle="dropdown"> Services<span class="caret"></span>
		</button>
		<ul class="dropdown-menu" role='menu' aria-labelledby="dropdownmenu1">
			<li><a href="services" role="menuitem">products</a> </li>
			<li><a href="#" role="menuitem">marketing</a> </li>
			<li><a href="#after sale" role="menuitem">after sale service</a> </li>
			<li><a href="#" role="menuitem">Delivery</a> </li>
			<li><a  href="#payment" role="menuitem">payment methods</a> </li>	
		</ul>
		</div>
		<button class="btn btn-primary" id="logi" data-toggle="modal" data-target="#login">login</button>
		<button class="btn btn-primary" id="regis" data-toggle="modal" data-target="#register">register</button>
		<a id="logout" class="btn btn-danger">logout</a>
	</div><hr>
	<div class="container shadow p-3 mb-5 bg-yellow rounded" style="border: 1px solid grey; padding-left: 10px;padding-right: 10px;">
		<div class="row">
		<div class="col-sm-12 col-lg-6 col-md-6">
			<h3 class="text-center" style="font-size: 25px;font-family: monospace;" >COVID-19 PANDEMIC</h3>
			<hr>
			<ul class="list-unlisted" style="font-family:bold;font-size: 20px; ">
				<li >Reguraly wash hands/Sanitize</li>
				<li>Keep Social Distance</li>
				<li>Maintain high personal hygiene</li>
				<li>Follow Government Directives</li>
			</ul><hr>
			
		</div>
		<div class="col-sm-12 col-md-6 col-lg-6">
			<h4 class="text-center" style="font-size: 23px;font-family: monospace;">We Shall Overcome</h4>
<table class="table"><th><button  class="btn btn-danger " style="margin-right: 20%;">COVID-19 test</button></th><th colspan="2"></th><th><button class="btn btn-primary" >Partener with us</button></th></table>
		</div>
		</div>
	</div>
	<div class="container">
				<div class="row">
					<div class="col-sm-12 col-md-6 col-lg-6">
						
						
					</div >
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div>
						<h3 class="text-center" style="font-size: 25px;font-family: monospace;" >TOGETHER WE SHALL OVERCOME COVID-9</h3>
						<hr>
						<p>
							For us to continue offering Reliable And Profesional services
							 in curbing the Spread of COVID-19 we need Dedicated team of:
							<ul>
								<li>Governmental Institutions</li>
								<li>Medical Practitioners</li>
								<li>Donors</li>
								<li>Volunteers</li>
								<Li>software Engineers</Li>
								<li>NGO'S</li>
							</ul>
 You can Partner with us a team or as an individual for collective achievement of curbing spread of COVID-19.
 
 <p>
 	Contact us Today <br>
 	lets Save the World Together.
 	<p>
 	Call :<a href="Tel:+254 791 799 466">+254 791 799 466</a>
Email: <a href="Email">inf</a>
 	</p>
 </p>
						</p>
					</div>
				</div>
			</div>
	

<?php /**PATH C:\xampp\htdocs\laravel\corona\resources\views/project/best.blade.php ENDPATH**/ ?>