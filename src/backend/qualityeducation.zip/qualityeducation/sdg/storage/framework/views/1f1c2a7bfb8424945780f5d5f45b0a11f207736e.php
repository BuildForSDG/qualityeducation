 <?php
?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('Assets/css/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('Assets/css/bootstrap.min.css')); ?>">
<script type="text/javascript" src="<?php echo e(asset('Assets/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Assets/js/bootstrap.bundle.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Assets/js/bootstrap.bundle.min.js')); ?>"></script>
<div style="background-color: #efefef;">
<div style="width: 100%; background: blue; color: white; height: 50px;">
    <a href="home" onclick="openNav()" style="font-size:30px;cursor:pointer"><img class="nav1" src="Assets/logos/hm.png"></a>
    <h5 class="text-center" >Fundisha Online Learning. Certify with us Today</h5>
    <p><a style="color: blue;" href="morecourses"><span style="font-size: 30px;">&#8592;</span></a> </p>
</div>
 <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container card summary bg-light text-black col-sm-12 col-md-12 col-lg-12" style="padding: 0px;">
	<div class="row">
	<div class="col-sm-12 col-md-2 col-lg-2">
		<a style="color: blue;" href="#"><?php echo e($value->course_title); ?></a><br>
		<?php for($i=0;$i<@count($chapter);$i++): ?>
 <a style="color: blue;" href='getchapters?id=<?php echo e($chapter[$i]->id); ?>&c_no=<?php echo e($chapter[$i]->c_no); ?>&course_id=<?php echo e($chapter[$i]->course_id); ?>'>Chapter <?php echo e($chapter[$i]->c_no); ?> <?php echo e($chapter[$i]->title); ?></a><br>
  <?php endfor; ?>
    </div>
    <div class="col-sm-12 col-md-10 col-lg-10">
    	<?php if(@count($ada)>0): ?>
    	<?php for($i=0;$i<@count($ada);$i++): ?>
 <p><?php echo e($ada[$i]->c_no); ?> <?php echo e($ada[$i]->title); ?></p>
 <p><?php echo e($ada[$i]->des); ?></p>
    	<video style="height: auto; width: 80%;" class="text-center" controls=""   poster='images/<?php echo e($ada[$i]->video); ?>' src='images/<?php echo e($ada[$i]->video); ?>'></video>
  <?php endfor; ?>
    	<?php else: ?>
    	<p><?php echo e($value->course_content); ?></p>
    	<video style="height: auto; width: 80%;"  controls=""   poster='images/<?php echo e($value->course_image); ?>' src='images/<?php echo e($value->course_video); ?>'></video>
    	<?php endif; ?>
    	
    </div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php echo $__env->make('project.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
    .image {
  display: inline-block;
  height: 30vh;
  width: 30vh;
  border-radius: 10px 10px 0px 0px;
  -webkit-border-radius: 10px 10px 0px 0px;
  -moz-border-radius: 10px 10px 0px 0px;
  -ms-border-radius: 10px 10px 0px 0px;
  -o-border-radius: 10px 10px 0px 0px;
}
a{
    color: white;
    height: 10px;
}
.container{
    padding: 15px;
}
.nav1{
margin-left: 5px;
    float: left;
    height: 50px
}
   </style>


<?php /**PATH C:\xampp\htdocs\qualityeducation\sdg\resources\views/project/learn.blade.php ENDPATH**/ ?>