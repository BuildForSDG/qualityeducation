<?php echo $__env->make('project.best', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p>here we go</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\corona\resources\views/project/services.blade.php ENDPATH**/ ?>