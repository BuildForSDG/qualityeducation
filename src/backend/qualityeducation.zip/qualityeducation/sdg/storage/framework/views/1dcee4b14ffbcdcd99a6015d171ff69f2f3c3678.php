<link rel="stylesheet" type="text/css" href="<?php echo e(asset('Assets/css/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('Assets/css/bootstrap.min.css')); ?>">

<script type="text/javascript" src="<?php echo e(asset('Assets/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Assets/js/bootstrap.bundle.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('Assets/js/bootstrap.bundle.min.js')); ?>"></script>
 <link href="Assets/css/literature.css" rel="stylesheet" type="text/css">
  <script src="Assets/js/script.js"></script>
   <link href="Assets/css/courses.css" rel="stylesheet" type="text/css">
<div style="width: 100%; background: #03396C; color: white; height: 50px;"> 
    <a href="home" onclick="openNav()" style="font-size:30px;cursor:pointer"><img class="nav1" src="Assets/logos/hm.png"></a>
    <h5 class="text-center" >We provide courses that will help you get certified on Various subjects</h5>
</div>
<div class="container col-sm-12 col-md-12 col-lg-12" style="background-color: #03396C;margin-top: -3px; ">
       <div class="row">
         <div class="col-sm-12 col-md-2 col-lg-2" style="">
            <a  class="btn btn-link" href="home">Home</a><br>
            <a  class="btn btn-link" href="morecourses">Courses</a><br>
            <a class="btn btn-link" href="jobs">Jobs</a><br>
            <a class="btn btn-link" href="profile">Profile</a><br>
            <a class="btn btn-link" href="">My Courses</a><br>
             <a class="btn btn-link" href="logout1"  id="logout" onClick="return confirm('Confirm Logout');">Logout</a><br>
            <img class="nav1" src="Assets/Imgs/registered.jpg">
         </div>
         <div class="col-sm-12 col-md-6 col-lg-6">
       <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="container card summary text-black col-sm-12 col-md-12 col-lg-12" style="background-color:#e2af6d; border-radius: 10px; " >
    <div class="row">
    <img src='images/<?php echo e($value->course_image); ?>' alt="Avatar" class="image col-sm-12 col-md-4 col-lg-4">
    <div class="col-sm-12 col-md-8 col-lg-8">
    <p class="text-center" style="color: white;"><?php echo e($value->course_title); ?></p>
    <p class=""><?php echo e($value->course_content); ?></p>
    <div class="text-center">
      <?php if($value->enrol=="enrolled"): ?>
<button id="enrolled" class="btn btn-success"><a href="enrol?course_id=<?php echo e($value->course_id); ?>">Enrolled click to continue learning</a></button>
<?php else: ?>
<p><?php echo e($value->enrol); ?></p>
 <button id="enrol" class="btn btn-primary"><a href="enrol?course_id=<?php echo e($value->course_id); ?>">Enrol to learn</a></button>
<?php endif; ?>
    </div>
    </div>
    </div>
     </div>

    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
         </div>
         <div class="col-sm-12 col-md-4 col-lg-4" style="margin-top: 40px;"> 
        <div class="progr">
            <div class="mag">
                <p1>Progress</p1>
                <p2>View All</p2>
                <img src="Assets/Imgs/MATH.jpg">
                <p3>Mathematics</p3>
                <button class="btn1"></button>
                <button class="btn2"></button>
                <p4>34%</p4>
                <img src="Assets/Imgs/ENGLISH.jpg">
                <p3>Literature</p3>
                <button class="btn1"></button>
                <button class="btn3"></button>
                <p4>80%</p4>
            </div>
        </div>
        <br>
        <div class="achie">
            <div class="magr">
                <p1>Achievements</p1>
                <p2>View All</p2>
                <img src="Assets/Imgs/rename.png">
                <p3>CERTIFICATE OF RECOGNITION</p3>
                <p4>SCIENCES</p4>
                <img id="str" src="Assets/Imgs/invisible star.png">
                <img id="str" src="Assets/Imgs/invisible star.png">
                <img id="str" src="Assets/Imgs/invisible star.png">
                <img id="str" src="Assets/Imgs/invisible star.png">
                <img id="str" src="Assets/Imgs/invisible 2.png">
            </div>
        </div>
    </div>
         </div>
       </div>
		 <?php echo $__env->make('project.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
   
   <style type="text/css">
   	.image {
  display: inline-block;
  height: 30vh;
  width: 30vh;
  border-radius: 10px 10px 0px 0px;
  -webkit-border-radius: 10px 10px 0px 0px;
  -moz-border-radius: 10px 10px 0px 0px;
  -ms-border-radius: 10px 10px 0px 0px;
  -o-border-radius: 10px 10px 0px 0px;
}
a,button{
	color: white;
}
.container{
	padding: 15px;
}
.nav1{
margin-left: 5px;
    float: left;
    height: 50px
}
.all1 img{
  width: 150px;
  height: 150px;
}
.all2 img{
  width: 20px;
  height: 20px;
}
   </style>
<?php if(session('email')): ?>
<style type="text/css">
    #login,#signup{
        display: none;
    }
    #logout{
        display: block;
    }
</style>
<?php else: ?>
<style type="text/css">
    #login,#signup{
        display: block;
    }
    #logout{
        display: none;
    }
</style>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\qualityeducation\sdg\resources\views/project/allcourses.blade.php ENDPATH**/ ?>