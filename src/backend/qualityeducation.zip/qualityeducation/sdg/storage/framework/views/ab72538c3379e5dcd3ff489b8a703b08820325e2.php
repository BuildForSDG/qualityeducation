<h3 class="text-center">Africa conctact list for COVID-19</h3>
	<div class="container">
		<div class="row">

			<div class="col-sm-6 col-lg-3 col-md-3">
	<p>Algeria:<br><a href="tel:3030">3030</a></p>
	<p>Angola:<br><a href="tel:111">111</a></p>
	<p>Republic of Benin:<br><a href="tel:+22995361104">+229 95361104</a><a href="tel:+22995361102">+22995361102</a> </p>
	<p>Botswana:<br><a href="tel:+267 3632273">+267 3632273</a> <a href="tel:+267 3632756">+267 3632756</a> <a href="tel:+267 3632757">+267 3632757</a></p>
	<p>Burkina Faso:<br><a href="tel:+226 1608989">+226 1608989</a><a href="tel:+226 52195394">+226 52195394</a></p>
	<p>Burundi:<br><a href="tel:+257 61636399">+257 61636399</a>,<a href="tel:+257 68768086">+257 68768086</a>,<a href="tel:+257 79962944">+257 79962944</a></p>
	<p>Cameroon:<br><a href="tel:1510">1510</a>,<a href="tel:+237 677899369">+237 677899369</a>,<a href="tel:+237 677894364">+237 677894364</a>,<a href="tel:+237 677897644">+237 677897644</a>,<a href="tel:+237 677900157">+237 677900157</a></p>
    <p>Cape Verde:<br><a href="tel:+238 8001112">+238 8001112</a></p>
    <p>Central African Republic:<br><a href="tel:1212">1212</a>,<a href="tel:+236 72287153">+236 72287153</a>,<a href="tel:+236 75233390">+236 75233390</a></p>
    <p>Chad:<a href="tel:1313">1313</a></p>

    <p>Comoros:<br><a href="tel:+269 4693641">+269 4693641</a></p>
    <p>Côte d’Ivoire:<br><a href="tel:143">143</a>,<a href="tel:144">144</a>,<a href="tel:101">101</a></p>
    <p>Democratic Republic of Congo:<br><a href="tel:+243 854463582">+243 854463582</a>, <a href="tel:+243 841363267">+243 841363267</a></p>
    </div>
			<div class="col-sm-6 col-lg-3 col-md-3">
    <p>Djibouti:<br><a href="tel:1517">1517</a></p>
    
    <p>Egypt:<br><a href="tel:105">105</a></p>
    <p>Equatorial Guinea:<br><a href="tel:1111">1111</a></p>
    <p>Eswatini:<br><a href="tel:977">977</a></p>
    <p>Ethiopia:<br><a href="tel:8335">8335</a></p>
    <p>Gabon:<br><a href="tel:1410">1410</a></p>
    <p>Gambia:<br><a href="1025">1025</a></p>
   
    <p>Ghana:<br><a href="+233 509497700">+233 509497700</a>,<a href="tel:+233 552222004">+233 552222004</a>,<a href="tel:+233 552222005">+233 552222005</a>,<a href="tel:+233 558439868">+233 558439868</a></p>
    <p>Guinea:<br><a href="tel:+224 629995656">+224 629995656</a></p>
    <p>Guinea Bissau:<br><a href="tel:1919">1919 (MTN)</a>,<a href="tel:2020"> 2020 (Orange)</a>,<a href="tel:+245 966050002">+245 966050002 (COES)</a></p>
    <p>Kenya:<br> <a href="tel:+254 800721316">+254 800721316</a>,<a href="tel:+254 732353535">+254 732353535</a>,<a href="tel:+254 729471414">+254 729471414</a>
    	,<a href="tel:719">719</a>,<a href="tel:*719#">*719#</a></p>
    	<p>Lesotho:<br><a href="tel:+266 58862893">+266 58862893</a></p>
    	
    	<p>Liberia:<br><a href="tel:4455">4455</a></p>
    	 </div>
	
			<div class="col-sm-6 col-lg-3 col-md-3">
    	<p>Libya:<br><a href="tel:191">191</a>,<a href="tel:193">193</a>,<a href="tel:+218 214631808">+218 214631808</a>,<a href="tel: +218 214631809"> +218 214631809</a>,<a href="tel:+218 214629191">+218 214629191</a>,<a href="tel:+218 214631807">+218 214631807</a>,<a href="tel:+218 921888999">+218 921888999</a>,<a href="tel:+218 924555554">+218 924555554</a>,<a href="tel:+218 926888999">218 926888999</a></p>
    	<p>Madagascar:<br><a href="tel:910">910</a></p>
    	<p>Malawi:<a href="tel:+265 887371288">+265 887371288</a></p>
    	<p>Mali:<br><a href="tel:36061">36061</a></p>
    	<p>Mauritania:<br><a href="tel:1155">1155</a></p>
    	<p>Mauritius:<br><a href="tel:8924">8924</a></p>
    	<p>Morocco:<br><a href="tel:+212 0801004747">+212 0801004747</a></p>
    	<p>Mozambique:<br><a href="tel:84146">84146</a>,<a href="tel:82149">82149</a>,<a href="tel:1490">1490</a>,<a href="tel:258">258</a>,<a href="tel:*660##">*660#</a></p>
    	<p>Namibia:<br> <a href="tel:0800100100">0800100100</a></p>
    	<p>Niger:<br><a href="tel:15">15</a></p>
    	<p>Nigeria:<br><a href="tel:+234 80097000010">+234 80097000010</a></p>
   
    	<p>Republic of the Congo:<br><a href="tel:3434">3434</a>,<a href="tel:+242 64787044">+242 64787044</a>,<a href="tel:+242 6405396">+242 6405396</a>,
<a href="tel:+242 55115702">+242 55115702</a>
    	</p> </div>
    
			<div class="col-sm-6 col-lg-3 col-md-3">
    	<p>Rwanda:<br><a href="tel:114">114</a></p>
    	<p>Senegal:<br><a href="tel:+221 800005050">+221 800005050</a></p>
    	<p>Seychelles:<br> <a href="tel:141">141</a></p>
    	<p>Sierra Leone:<br><a href="tel:117">117</a></p>
    	<p>Somalia:<br><a href="tel:449">449</a></p>
    	<p>South Africa:<br><a href="tel:0800111131">0800111131 (clinician hotline)</a>,<a href="tel:0800029999">0800029999 (public hotline)</a></p>
    	<p>South Sudan:<br><a href="tel:6666">6666</a></p>
    	<p>Sudan:<br><a href="tel:9090">9090</a></p>
    	<p>Tanzania:<br><a href="tel:199">199</a></p>
    	<p>Togo:<br><a href="tel:+228 22222073">+228 22222073</a>,<a href="tel:+228 91674242">+228 91674242</a></p>
    	<p>Tunisia:<br><a href="tel:+216 80101919">+216 80101919</a></p>
    	<p>Uganda:<br><a href="tel:+256 800203033">+256 800203033</a>,<a href="tel:+256 800100066">+256 800100066</a></p>
    	<p>Zambia:<br><a href="tel:909">909</a>,<a href="tel:+260974493553">+260974493553</a>,<a href="tel:+260964638726">+260964638726</a>,<a href="tel:+260953898941">+260953898941</a></p>
    	<p>Zimbabwe:<br><a href="tel:+263714734593">+263714734593</a>,<a href="tel:+263774112531">+263774112531</a></p>
    </div></div>
</body>
</html>
<style type="text/css">
	.btn{
	margin-right: 2vh;
	float: right;
	margin-top: 1vh;

}
p{
	width: 100%;
	font-size: 20px;
}
</style><?php /**PATH C:\xampp\htdocs\laravel\corona\resources\views/project/contacts.blade.php ENDPATH**/ ?>