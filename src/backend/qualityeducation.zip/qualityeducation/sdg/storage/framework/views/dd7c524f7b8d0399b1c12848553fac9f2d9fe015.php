<!DOCTYPE html>
<html>
<head>
	<title>laravel one</title>
</head>
<body>
<h1>my name is francis</h1>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\corona\resources\views/project/francis.blade.php ENDPATH**/ ?>