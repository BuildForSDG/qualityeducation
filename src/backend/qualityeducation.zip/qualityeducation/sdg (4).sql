-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2020 at 08:21 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sdg`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `firstname` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DOB` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`firstname`, `lastname`, `email`, `country`, `mobile`, `gender`, `DOB`, `password`) VALUES
('francis', 'warui', 'warui@gmail.com', 'kenya', '0705731168', 'male', '12/01/1212', '12345678'),
('Francis', 'kinyuru', 'waruikinyuru@gmail.com', 'ke', '0705731168', NULL, NULL, '25d55ad283aa400af464c76d713c07ad');

-- --------------------------------------------------------

--
-- Table structure for table `chapters`
--

CREATE TABLE `chapters` (
  `id` int(11) NOT NULL,
  `course_id` varchar(1000) NOT NULL,
  `c_no` varchar(1000) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `des` mediumtext NOT NULL,
  `video` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chapters`
--

INSERT INTO `chapters` (`id`, `course_id`, `c_no`, `title`, `des`, `video`, `date`) VALUES
(1, 'math101', 'one', 'introduction', 'dvjvkldfkfd;ld;lf', 'vlc-record-2019-08-01-18h43m00s-secrets.and.lies.us.109.hdtv-lol.mp4-.mp4', '2020-06-09 10:20:41'),
(2, '233', 'one', 'introduction', 'here we go', 'vlc-record-2019-08-01-18h43m00s-secrets.and.lies.us.109.hdtv-lol.mp4-.mp4', '2020-06-15 21:20:56');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_image` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_video` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `course_content` mediumtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_title`, `course_image`, `course_video`, `course_content`) VALUES
('math101', 'Basic Mathematics', 'about.png', 'vlc-record-2019-08-01-18h43m00s-secrets.and.lies.us.109.hdtv-lol.mp4-.mp4', 'nnmkl'),
('233', 'English Literature', 'about.png', 'vlc-record-2019-08-01-18h43m00s-secrets.and.lies.us.109.hdtv-lol.mp4-.mp4', 'c clk lxk lzxklz xzxkzxkkzx');

-- --------------------------------------------------------

--
-- Table structure for table `enrolled`
--

CREATE TABLE `enrolled` (
  `course_id` varchar(1000) NOT NULL,
  `email` varchar(1000) DEFAULT NULL,
  `progress` varchar(1000) DEFAULT NULL,
  `enrol` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enrolled`
--

INSERT INTO `enrolled` (`course_id`, `email`, `progress`, `enrol`) VALUES
('math101', 'ivene@gmail.com', NULL, 'enrolled'),
('233', 'ivene@gmail.com', NULL, 'enrolled'),
('math101', 'franciskinyuru26@gmail.com', NULL, 'enrolled'),
('233', 'franciskinyuru26@gmail.com', NULL, 'enrolled'),
('233', NULL, NULL, 'enrolled'),
('math101', NULL, NULL, 'enrolled');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `job_id` int(10) UNSIGNED NOT NULL,
  `job_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_description` mediumtext COLLATE utf8mb4_unicode_ci,
  `job_attachment` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `application_deadline` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`job_id`, `job_title`, `job_description`, `job_attachment`, `application_deadline`, `created_at`, `email`) VALUES
(12, 'Maths-physics techear required', 'tyyuuiooooo', 'donate.jpg', '2020-06-12', '2020-06-08', 'waruikinyuru@gmail.com'),
(13, 'life skills', 'life skills trainer', 'exam_application.PNG', '2020-06-12', '2020-06-08', 'gladys@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `firstname` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DOB` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`firstname`, `lastname`, `email`, `country`, `mobile`, `gender`, `DOB`, `password`) VALUES
('Francis', 'kinyuru', 'franciskinyuru26@gmail.com', 'ke', '0705731168', 'male', '2020-06-25', '25d55ad283aa400af464c76d713c07ad'),
('Francis', 'kinyuru', 'ivene@gmail.com', 'ke', '0705731168', 'male', '2020-06-25', '25d55ad283aa400af464c76d713c07ad'),
(NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'd41d8cd98f00b204e9800998ecf8427e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD UNIQUE KEY `admin_email_unique` (`email`);

--
-- Indexes for table `chapters`
--
ALTER TABLE `chapters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chapters`
--
ALTER TABLE `chapters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `job_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
